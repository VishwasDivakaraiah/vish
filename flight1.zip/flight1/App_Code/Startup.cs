﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(flight1.Startup))]
namespace flight1
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
